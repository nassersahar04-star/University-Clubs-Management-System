package com.uniclubs.config;

import com.uniclubs.model.*;
import com.uniclubs.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ClubRepository clubRepository;
    private final MembershipRepository membershipRepository;
    private final EventRepository eventRepository;
    private final TaskRepository taskRepository;
    private final AnnouncementRepository announcementRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, ClubRepository clubRepository,
                           MembershipRepository membershipRepository, EventRepository eventRepository,
                           TaskRepository taskRepository, AnnouncementRepository announcementRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.clubRepository = clubRepository;
        this.membershipRepository = membershipRepository;
        this.eventRepository = eventRepository;
        this.taskRepository = taskRepository;
        this.announcementRepository = announcementRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (userRepository.count() > 0) return;

        // Create users
        User admin = new User("admin", "admin@uni.edu", passwordEncoder.encode("password"), User.Role.ADMIN);
        User leader1 = new User("leader1", "leader1@uni.edu", passwordEncoder.encode("password"), User.Role.CLUB_LEADER);
        User leader2 = new User("leader2", "leader2@uni.edu", passwordEncoder.encode("password"), User.Role.CLUB_LEADER);
        User member1 = new User("member1", "member1@uni.edu", passwordEncoder.encode("password"), User.Role.MEMBER);
        User member2 = new User("member2", "member2@uni.edu", passwordEncoder.encode("password"), User.Role.MEMBER);

        admin = userRepository.save(admin);
        leader1 = userRepository.save(leader1);
        leader2 = userRepository.save(leader2);
        member1 = userRepository.save(member1);
        member2 = userRepository.save(member2);

        // Create clubs
        Club codingClub = new Club("Coding Club", "Technology", "A community for coding enthusiasts to learn, build, and share projects together.", leader1);
        Club photoClub = new Club("Photography Society", "Arts", "Capture moments and learn professional photography techniques.", leader2);
        Club basketballClub = new Club("Basketball Team", "Sports", "Competitive basketball team representing the university.", leader1);

        codingClub = clubRepository.save(codingClub);
        photoClub = clubRepository.save(photoClub);
        basketballClub = clubRepository.save(basketballClub);

        // Create memberships
        Membership m1 = new Membership(leader1, codingClub);
        m1.setStatus(Membership.Status.APPROVED);
        membershipRepository.save(m1);

        Membership m2 = new Membership(leader2, photoClub);
        m2.setStatus(Membership.Status.APPROVED);
        membershipRepository.save(m2);

        Membership m3 = new Membership(leader1, basketballClub);
        m3.setStatus(Membership.Status.APPROVED);
        membershipRepository.save(m3);

        Membership m4 = new Membership(member1, codingClub);
        m4.setStatus(Membership.Status.PENDING);
        membershipRepository.save(m4);

        Membership m5 = new Membership(member2, photoClub);
        m5.setStatus(Membership.Status.PENDING);
        membershipRepository.save(m5);

        Membership m6 = new Membership(member1, photoClub);
        m6.setStatus(Membership.Status.APPROVED);
        membershipRepository.save(m6);

        // Create events
        eventRepository.save(new Event("Hackathon 2026", "24-hour coding competition with prizes.",
                LocalDateTime.of(2026, 5, 15, 9, 0), "Engineering Building", 50, codingClub));
        eventRepository.save(new Event("Photo Walk", "Campus photography walk and workshop.",
                LocalDateTime.of(2026, 5, 10, 14, 0), "University Garden", 20, photoClub));
        eventRepository.save(new Event("Spring Tournament", "Inter-university basketball tournament.",
                LocalDateTime.of(2026, 5, 20, 10, 0), "Sports Complex", 100, basketballClub));

        // Create tasks
        Task t1 = new Task("Prepare presentation", "Create slides for the next club meeting.", codingClub, member1);
        taskRepository.save(t1);

        Task t2 = new Task("Design poster", "Design event poster for the hackathon.", codingClub, member1);
        t2.setStatus(Task.Status.IN_PROGRESS);
        taskRepository.save(t2);

        Task t3 = new Task("Book venue", "Reserve the main hall for the tournament.", basketballClub, leader1);
        t3.setStatus(Task.Status.COMPLETED);
        taskRepository.save(t3);

        // Create announcements
        announcementRepository.save(new Announcement("Welcome to Coding Club!", "We are excited to start the new semester. Join us for our first meeting next Monday.", codingClub, leader1));
        announcementRepository.save(new Announcement("New Equipment Arrived", "The new cameras and lenses have arrived. Check them out at the club room.", photoClub, leader2));
        announcementRepository.save(new Announcement("System Maintenance", "The platform will undergo maintenance this weekend.", null, admin));
    }
}
