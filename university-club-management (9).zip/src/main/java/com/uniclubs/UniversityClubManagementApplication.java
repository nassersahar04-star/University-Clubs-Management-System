package com.uniclubs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityClubManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(UniversityClubManagementApplication.class, args);
    }
}
