package com.uniclubs.repository;

import com.uniclubs.model.Club;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ClubRepository extends JpaRepository<Club, Long> {
    List<Club> findByLeaderId(Long leaderId);
    long countByLeaderId(Long leaderId);
}
