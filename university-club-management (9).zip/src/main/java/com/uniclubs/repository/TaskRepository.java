package com.uniclubs.repository;

import com.uniclubs.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByClubId(Long clubId);
    List<Task> findByAssigneeId(Long assigneeId);
    List<Task> findByClubIdAndStatus(Long clubId, Task.Status status);
    long countByAssigneeIdAndStatus(Long assigneeId, Task.Status status);
}
