package com.uniclubs.repository;

import com.uniclubs.model.Membership;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface MembershipRepository extends JpaRepository<Membership, Long> {
    List<Membership> findByClubId(Long clubId);
    List<Membership> findByUserId(Long userId);
    List<Membership> findByClubIdAndStatus(Long clubId, Membership.Status status);
    Optional<Membership> findByUserIdAndClubId(Long userId, Long clubId);
    long countByStatus(Membership.Status status);
    boolean existsByUserIdAndClubIdAndStatus(Long userId, Long clubId, Membership.Status status);
}
