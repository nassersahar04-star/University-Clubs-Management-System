package com.uniclubs.service;

import com.uniclubs.model.Task;
import com.uniclubs.repository.TaskRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public List<Task> findAll() {
        return taskRepository.findAll();
    }

    public List<Task> findByClub(Long clubId) {
        return taskRepository.findByClubId(clubId);
    }

    public List<Task> findByAssignee(Long assigneeId) {
        return taskRepository.findByAssigneeId(assigneeId);
    }

    public List<Task> findPendingByAssignee(Long assigneeId) {
        return taskRepository.findByAssigneeId(assigneeId).stream()
                .filter(t -> t.getStatus() != Task.Status.COMPLETED)
                .toList();
    }

    public Optional<Task> findById(Long id) {
        return taskRepository.findById(id);
    }

    public Task save(Task task) {
        return taskRepository.save(task);
    }

    public void delete(Long id) {
        taskRepository.deleteById(id);
    }

    @org.springframework.transaction.annotation.Transactional
    public void updateStatus(Long taskId, Task.Status status) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        task.setStatus(status);
        taskRepository.save(task);
    }

    public long countPendingTasks(Long userId) {
        return taskRepository.countByAssigneeIdAndStatus(userId, Task.Status.PENDING);
    }
}
