package com.uniclubs.service;

import com.uniclubs.dto.ClubDto;
import com.uniclubs.model.Club;
import com.uniclubs.model.Membership;
import com.uniclubs.model.User;
import com.uniclubs.repository.ClubRepository;
import com.uniclubs.repository.MembershipRepository;
import com.uniclubs.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class ClubService {
    private final ClubRepository clubRepository;
    private final UserRepository userRepository;
    private final MembershipRepository membershipRepository;

    public ClubService(ClubRepository clubRepository, UserRepository userRepository, MembershipRepository membershipRepository) {
        this.clubRepository = clubRepository;
        this.userRepository = userRepository;
        this.membershipRepository = membershipRepository;
    }

    public List<Club> findAll() {
        return clubRepository.findAll();
    }

    public Optional<Club> findById(Long id) {
        return clubRepository.findById(id);
    }

    @Transactional
    public Club createClub(ClubDto dto) {
        User leader = userRepository.findById(dto.getLeaderId())
                .orElseThrow(() -> new RuntimeException("Leader not found"));
        Club club = new Club(dto.getName(), dto.getCategory(), dto.getDescription(), leader);
        Club saved = clubRepository.save(club);
        // Auto-approve leader as member
        Membership leaderMembership = new Membership(leader, saved);
        leaderMembership.setStatus(Membership.Status.APPROVED);
        membershipRepository.save(leaderMembership);
        return saved;
    }

    @Transactional
    public Club updateClub(Long id, ClubDto dto) {
        Club club = clubRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Club not found"));
        club.setName(dto.getName());
        club.setCategory(dto.getCategory());
        club.setDescription(dto.getDescription());
        if (dto.getLeaderId() != null) {
            User leader = userRepository.findById(dto.getLeaderId())
                    .orElseThrow(() -> new RuntimeException("Leader not found"));
            club.setLeader(leader);
        }
        return clubRepository.save(club);
    }

    @Transactional
    public void deleteClub(Long id) {
        clubRepository.deleteById(id);
    }

    public List<Club> findByLeader(Long leaderId) {
        return clubRepository.findByLeaderId(leaderId);
    }

    public long countClubs() {
        return clubRepository.count();
    }
}
