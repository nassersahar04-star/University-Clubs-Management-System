package com.uniclubs.service;

import com.uniclubs.model.Membership;
import com.uniclubs.repository.MembershipRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class MembershipService {
    private final MembershipRepository membershipRepository;

    public MembershipService(MembershipRepository membershipRepository) {
        this.membershipRepository = membershipRepository;
    }

    public List<Membership> findByClub(Long clubId) {
        return membershipRepository.findByClubId(clubId);
    }

    public List<Membership> findPendingByClub(Long clubId) {
        return membershipRepository.findByClubIdAndStatus(clubId, Membership.Status.PENDING);
    }

    public List<Membership> findByUser(Long userId) {
        return membershipRepository.findByUserId(userId);
    }

    @Transactional
    public Membership requestMembership(Long userId, Long clubId) {
        Optional<Membership> existing = membershipRepository.findByUserIdAndClubId(userId, clubId);
        if (existing.isPresent()) {
            throw new RuntimeException("Membership request already exists");
        }
        Membership membership = new Membership();
        membership.setUser(new com.uniclubs.model.User() {{ setId(userId); }});
        membership.setClub(new com.uniclubs.model.Club() {{ setId(clubId); }});
        membership.setStatus(Membership.Status.PENDING);
        return membershipRepository.save(membership);
    }

    @Transactional
    public void approveMembership(Long membershipId) {
        Membership membership = membershipRepository.findById(membershipId)
                .orElseThrow(() -> new RuntimeException("Membership not found"));
        membership.setStatus(Membership.Status.APPROVED);
        membershipRepository.save(membership);
    }

    @Transactional
    public void rejectMembership(Long membershipId) {
        Membership membership = membershipRepository.findById(membershipId)
                .orElseThrow(() -> new RuntimeException("Membership not found"));
        membership.setStatus(Membership.Status.REJECTED);
        membershipRepository.save(membership);
    }

    public boolean isMember(Long userId, Long clubId) {
        return membershipRepository.existsByUserIdAndClubIdAndStatus(userId, clubId, Membership.Status.APPROVED);
    }

    public long countPending() {
        return membershipRepository.countByStatus(Membership.Status.PENDING);
    }
}
