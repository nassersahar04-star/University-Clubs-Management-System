package com.uniclubs.controller;

import com.uniclubs.model.User;
import com.uniclubs.service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final UserService userService;
    private final ClubService clubService;
    private final MembershipService membershipService;

    public AdminController(UserService userService, ClubService clubService, MembershipService membershipService) {
        this.userService = userService;
        this.clubService = clubService;
        this.membershipService = membershipService;
    }

    @GetMapping("/users")
    public String listUsers(Model model) {
        model.addAttribute("users", userService.findAll());
        return "admin/users";
    }

    @PostMapping("/users/{id}/delete")
    public String deleteUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        userService.deleteUser(id);
        redirectAttributes.addFlashAttribute("successMessage", "User deleted!");
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/role")
    public String updateRole(@PathVariable Long id, @RequestParam User.Role role,
                             RedirectAttributes redirectAttributes) {
        User user = userService.findById(id).orElseThrow();
        user.setRole(role);
        userService.save(user);
        redirectAttributes.addFlashAttribute("successMessage", "Role updated!");
        return "redirect:/admin/users";
    }

    @GetMapping("/clubs")
    public String listClubs(Model model) {
        model.addAttribute("clubs", clubService.findAll());
        return "admin/clubs";
    }
}
