package com.uniclubs.controller;

import com.uniclubs.model.User;
import com.uniclubs.service.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {
    private final UserService userService;
    private final ClubService clubService;
    private final EventService eventService;
    private final TaskService taskService;
    private final AnnouncementService announcementService;
    private final MembershipService membershipService;

    public DashboardController(UserService userService, ClubService clubService,
                               EventService eventService, TaskService taskService,
                               AnnouncementService announcementService, MembershipService membershipService) {
        this.userService = userService;
        this.clubService = clubService;
        this.eventService = eventService;
        this.taskService = taskService;
        this.announcementService = announcementService;
        this.membershipService = membershipService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        model.addAttribute("currentUser", user);

        var stats = new java.util.HashMap<String, Object>();
        stats.put("totalClubs", clubService.countClubs());
        stats.put("totalUsers", userService.countUsers());
        stats.put("totalEvents", eventService.countEvents());
        stats.put("announcements", announcementService.countAnnouncements());
        stats.put("pendingRequests", membershipService.countPending());
        stats.put("myEvents", eventService.findAll().size());
        stats.put("pendingTasks", taskService.countPendingTasks(user.getId()));
        stats.put("activeEvents", eventService.countEvents());
        stats.put("myClubs", membershipService.findByUser(user.getId()).stream()
                .filter(m -> m.getStatus() == com.uniclubs.model.Membership.Status.APPROVED).count());

        model.addAttribute("stats", stats);
        model.addAttribute("announcements", announcementService.findAll().stream().limit(5).toList());
        model.addAttribute("myTasks", taskService.findByAssignee(user.getId()).stream().limit(5).toList());
        model.addAttribute("clubs", clubService.findAll());

        return "dashboard";
    }
}
