package com.uniclubs.controller;

import com.uniclubs.model.Club;
import com.uniclubs.model.Event;
import com.uniclubs.service.ClubService;
import com.uniclubs.service.EventService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
public class EventController {
    private final EventService eventService;
    private final ClubService clubService;

    public EventController(EventService eventService, ClubService clubService) {
        this.eventService = eventService;
        this.clubService = clubService;
    }

    @GetMapping("/events")
    public String listEvents(Model model) {
        model.addAttribute("events", eventService.findAll());
        return "events/list";
    }

    @GetMapping("/clubs/{clubId}/events/create")
    public String createForm(@PathVariable Long clubId, Model model) {
        model.addAttribute("clubId", clubId);
        return "events/form";
    }

    @PostMapping("/clubs/{clubId}/events/create")
    public String createEvent(@PathVariable Long clubId,
                              @RequestParam String name,
                              @RequestParam String description,
                              @RequestParam String eventDate,
                              @RequestParam String location,
                              @RequestParam Integer capacity,
                              RedirectAttributes redirectAttributes) {
        Club club = clubService.findById(clubId).orElseThrow();
        Event event = new Event();
        event.setName(name);
        event.setDescription(description);
        event.setEventDate(LocalDateTime.parse(eventDate));
        event.setLocation(location);
        event.setCapacity(capacity);
        event.setClub(club);
        eventService.save(event);
        redirectAttributes.addFlashAttribute("successMessage", "Event created successfully!");
        return "redirect:/clubs/" + clubId;
    }

    @PostMapping("/events/{id}/delete")
    public String deleteEvent(@PathVariable Long id, @RequestParam Long clubId,
                              RedirectAttributes redirectAttributes) {
        eventService.delete(id);
        redirectAttributes.addFlashAttribute("successMessage", "Event deleted!");
        return "redirect:/clubs/" + clubId;
    }
}
