package com.uniclubs.controller;

import com.uniclubs.model.Task;
import com.uniclubs.model.User;
import com.uniclubs.service.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class TaskController {
    private final TaskService taskService;
    private final ClubService clubService;
    private final UserService userService;

    public TaskController(TaskService taskService, ClubService clubService, UserService userService) {
        this.taskService = taskService;
        this.clubService = clubService;
        this.userService = userService;
    }

    @GetMapping("/tasks")
    public String listTasks(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        model.addAttribute("tasks", taskService.findByAssignee(user.getId()));
        model.addAttribute("allTasks", taskService.findAll());
        return "tasks/list";
    }

    @GetMapping("/clubs/{clubId}/tasks/create")
    public String createForm(@PathVariable Long clubId, Model model) {
        model.addAttribute("clubId", clubId);
        model.addAttribute("members", userService.findAll());
        return "tasks/form";
    }

    @PostMapping("/clubs/{clubId}/tasks/create")
    public String createTask(@PathVariable Long clubId,
                             @RequestParam String title,
                             @RequestParam String description,
                             @RequestParam Long assigneeId,
                             RedirectAttributes redirectAttributes) {
        Task task = new Task();
        task.setTitle(title);
        task.setDescription(description);
        task.setClub(clubService.findById(clubId).orElseThrow());
        task.setAssignee(userService.findById(assigneeId).orElseThrow());
        task.setStatus(Task.Status.PENDING);
        taskService.save(task);
        redirectAttributes.addFlashAttribute("successMessage", "Task assigned successfully!");
        return "redirect:/clubs/" + clubId;
    }

    @PostMapping("/tasks/{id}/status")
    public String updateStatus(@PathVariable Long id,
                               @RequestParam Task.Status status,
                               RedirectAttributes redirectAttributes) {
        taskService.updateStatus(id, status);
        redirectAttributes.addFlashAttribute("successMessage", "Task status updated!");
        return "redirect:/tasks";
    }

    @PostMapping("/tasks/{id}/delete")
    public String deleteTask(@PathVariable Long id, @RequestParam(required = false) Long clubId,
                             RedirectAttributes redirectAttributes) {
        taskService.delete(id);
        redirectAttributes.addFlashAttribute("successMessage", "Task deleted!");
        return clubId != null ? "redirect:/clubs/" + clubId : "redirect:/tasks";
    }
}
