package com.uniclubs.controller;

import com.uniclubs.model.Announcement;
import com.uniclubs.model.User;
import com.uniclubs.service.AnnouncementService;
import com.uniclubs.service.ClubService;
import com.uniclubs.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AnnouncementController {
    private final AnnouncementService announcementService;
    private final ClubService clubService;
    private final UserService userService;

    public AnnouncementController(AnnouncementService announcementService, ClubService clubService, UserService userService) {
        this.announcementService = announcementService;
        this.clubService = clubService;
        this.userService = userService;
    }

    @GetMapping("/announcements")
    public String listAnnouncements(Model model) {
        model.addAttribute("announcements", announcementService.findAll());
        return "announcements/list";
    }

    @GetMapping("/clubs/{clubId}/announcements/create")
    public String createForm(@PathVariable Long clubId, Model model) {
        model.addAttribute("clubId", clubId);
        return "announcements/form";
    }

    @PostMapping("/clubs/{clubId}/announcements/create")
    public String createAnnouncement(@PathVariable Long clubId,
                                     @RequestParam String title,
                                     @RequestParam String content,
                                     @AuthenticationPrincipal UserDetails userDetails,
                                     RedirectAttributes redirectAttributes) {
        User author = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        Announcement announcement = new Announcement();
        announcement.setTitle(title);
        announcement.setContent(content);
        announcement.setClub(clubService.findById(clubId).orElseThrow());
        announcement.setAuthor(author);
        announcementService.save(announcement);
        redirectAttributes.addFlashAttribute("successMessage", "Announcement posted!");
        return "redirect:/clubs/" + clubId;
    }

    @PostMapping("/announcements/{id}/delete")
    public String deleteAnnouncement(@PathVariable Long id, @RequestParam(required = false) Long clubId,
                                     RedirectAttributes redirectAttributes) {
        announcementService.delete(id);
        redirectAttributes.addFlashAttribute("successMessage", "Announcement deleted!");
        return clubId != null ? "redirect:/clubs/" + clubId : "redirect:/announcements";
    }
}
