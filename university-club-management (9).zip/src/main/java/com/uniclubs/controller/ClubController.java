package com.uniclubs.controller;

import com.uniclubs.dto.ClubDto;
import com.uniclubs.model.Club;
import com.uniclubs.model.Membership;
import com.uniclubs.model.User;
import com.uniclubs.service.*;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ClubController {
    private final ClubService clubService;
    private final UserService userService;
    private final MembershipService membershipService;
    private final EventService eventService;
    private final TaskService taskService;
    private final AnnouncementService announcementService;

    public ClubController(ClubService clubService, UserService userService,
                          MembershipService membershipService, EventService eventService,
                          TaskService taskService, AnnouncementService announcementService) {
        this.clubService = clubService;
        this.userService = userService;
        this.membershipService = membershipService;
        this.eventService = eventService;
        this.taskService = taskService;
        this.announcementService = announcementService;
    }

    @GetMapping("/clubs")
    public String listClubs(Model model) {
        model.addAttribute("clubs", clubService.findAll());
        return "clubs/list";
    }

    @GetMapping("/clubs/{id}")
    public String clubDetail(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        Club club = clubService.findById(id).orElseThrow(() -> new RuntimeException("Club not found"));
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        model.addAttribute("club", club);
        model.addAttribute("isMember", membershipService.isMember(user.getId(), id));
        model.addAttribute("hasPendingRequest", membershipService.findByUser(user.getId()).stream()
                .anyMatch(m -> m.getClub().getId().equals(id) && m.getStatus() == Membership.Status.PENDING));
        model.addAttribute("memberships", membershipService.findByClub(id));
        model.addAttribute("events", eventService.findByClub(id));
        model.addAttribute("tasks", taskService.findByClub(id));
        model.addAttribute("announcements", announcementService.findByClub(id));
        return "clubs/detail";
    }

    @GetMapping("/clubs/create")
    public String createForm(Model model) {
        model.addAttribute("clubDto", new ClubDto());
        model.addAttribute("leaders", userService.findByRole(User.Role.CLUB_LEADER));
        return "clubs/form";
    }

    @PostMapping("/clubs/create")
    public String createClub(@Valid @ModelAttribute("clubDto") ClubDto clubDto,
                             BindingResult result, Model model, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("leaders", userService.findByRole(User.Role.CLUB_LEADER));
            return "clubs/form";
        }
        clubService.createClub(clubDto);
        redirectAttributes.addFlashAttribute("successMessage", "Club created successfully!");
        return "redirect:/clubs";
    }

    @GetMapping("/clubs/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        Club club = clubService.findById(id).orElseThrow();
        ClubDto dto = new ClubDto();
        dto.setName(club.getName());
        dto.setCategory(club.getCategory());
        dto.setDescription(club.getDescription());
        dto.setLeaderId(club.getLeader() != null ? club.getLeader().getId() : null);
        model.addAttribute("clubDto", dto);
        model.addAttribute("clubId", id);
        model.addAttribute("leaders", userService.findByRole(User.Role.CLUB_LEADER));
        return "clubs/form";
    }

    @PostMapping("/clubs/{id}/edit")
    public String updateClub(@PathVariable Long id, @Valid @ModelAttribute("clubDto") ClubDto clubDto,
                             BindingResult result, Model model, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("clubId", id);
            model.addAttribute("leaders", userService.findByRole(User.Role.CLUB_LEADER));
            return "clubs/form";
        }
        clubService.updateClub(id, clubDto);
        redirectAttributes.addFlashAttribute("successMessage", "Club updated successfully!");
        return "redirect:/clubs";
    }

    @PostMapping("/clubs/{id}/delete")
    public String deleteClub(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        clubService.deleteClub(id);
        redirectAttributes.addFlashAttribute("successMessage", "Club deleted successfully!");
        return "redirect:/clubs";
    }

    @PostMapping("/clubs/{id}/join")
    public String joinClub(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails,
                           RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        try {
            membershipService.requestMembership(user.getId(), id);
            redirectAttributes.addFlashAttribute("successMessage", "Join request sent!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/clubs/" + id;
    }

    @PostMapping("/memberships/{id}/approve")
    public String approveMembership(@PathVariable Long id, @RequestParam Long clubId,
                                    RedirectAttributes redirectAttributes) {
        membershipService.approveMembership(id);
        redirectAttributes.addFlashAttribute("successMessage", "Member approved!");
        return "redirect:/clubs/" + clubId;
    }

    @PostMapping("/memberships/{id}/reject")
    public String rejectMembership(@PathVariable Long id, @RequestParam Long clubId,
                                   RedirectAttributes redirectAttributes) {
        membershipService.rejectMembership(id);
        redirectAttributes.addFlashAttribute("successMessage", "Member rejected!");
        return "redirect:/clubs/" + clubId;
    }
}
