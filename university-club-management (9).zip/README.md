# University Club Management Platform

A complete Java Spring Boot web application for managing university clubs, members, events, and activities.

## Features

- **Role-based access control**: Admin, Club Leader, Member
- **Club Management**: Create, edit, delete clubs
- **Membership System**: Request to join, approve/reject members
- **Event Management**: Create events with date, location, capacity
- **Task Assignment**: Assign tasks to members and track completion
- **Announcements**: Post and manage club announcements
- **Interactive Dashboard**: Role-based dashboards with statistics
- **Responsive UI**: Mobile-friendly Bootstrap 5 design

## Tech Stack

- Java 17
- Spring Boot 3.2.5
- Spring Security (BCrypt password encoding)
- Spring Data JPA
- Thymeleaf (server-side templating)
- H2 Database (in-memory)
- Bootstrap 5 + Bootstrap Icons

## Quick Start

### Prerequisites
- Java 17 or higher
- Maven 3.8+

### Run the Application

```bash
# Navigate to project directory
cd university-club-management

# Run with Maven
mvn spring-boot:run

# Or build and run
mvn clean package
java -jar target/university-club-management-1.0.0.jar
```

The application will start on **http://localhost:8080**

### Demo Accounts

All accounts use password: `password`

| Username | Role | Description |
|----------|------|-------------|
| admin | ADMIN | Full system access |
| leader1 | CLUB_LEADER | Leader of Coding Club & Basketball Team |
| leader2 | CLUB_LEADER | Leader of Photography Society |
| member1 | MEMBER | Regular member with pending requests |
| member2 | MEMBER | Regular member |

### H2 Database Console
Access at: **http://localhost:8080/h2-console**
- JDBC URL: `jdbc:h2:mem:uniclubsdb`
- Username: `sa`
- Password: *(leave empty)*

## Team Distribution (5 Members)

| Member | Role | Files/Responsibility |
|--------|------|---------------------|
| **Person 1** | Backend Lead | `pom.xml`, `application.properties`, `SecurityConfig.java`, `DataInitializer.java`, project setup |
| **Person 2** | Club & Membership | `Club.java`, `Membership.java`, `ClubController.java`, `ClubService.java`, `MembershipService.java`, club templates |
| **Person 3** | Events & Announcements | `Event.java`, `Announcement.java`, `EventController.java`, `AnnouncementController.java`, `EventService.java`, `AnnouncementService.java`, event/announcement templates |
| **Person 4** | Tasks & Admin | `Task.java`, `AdminController.java`, `TaskController.java`, `TaskService.java`, `UserService.java`, task/admin templates |
| **YOU** | Frontend Lead | `base.html`, `login.html`, `register.html`, `dashboard.html`, `style.css`, `main.js`, UI/UX polish |

## Project Structure

```
src/main/java/com/uniclubs/
├── UniversityClubManagementApplication.java
├── config/
│   ├── SecurityConfig.java
│   └── DataInitializer.java
├── controller/
│   ├── AuthController.java
│   ├── DashboardController.java
│   ├── ClubController.java
│   ├── EventController.java
│   ├── TaskController.java
│   ├── AnnouncementController.java
│   └── AdminController.java
├── model/
│   ├── User.java
│   ├── Club.java
│   ├── Membership.java
│   ├── Event.java
│   ├── Task.java
│   └── Announcement.java
├── repository/
│   ├── UserRepository.java
│   ├── ClubRepository.java
│   ├── MembershipRepository.java
│   ├── EventRepository.java
│   ├── TaskRepository.java
│   └── AnnouncementRepository.java
├── service/
│   ├── CustomUserDetailsService.java
│   ├── UserService.java
│   ├── ClubService.java
│   ├── MembershipService.java
│   ├── EventService.java
│   ├── TaskService.java
│   └── AnnouncementService.java
└── dto/
    └── ClubDto.java

src/main/resources/
├── application.properties
├── static/
│   ├── css/style.css
│   └── js/main.js
└── templates/
    ├── base.html
    ├── login.html
    ├── register.html
    ├── dashboard.html
    ├── clubs/
    │   ├── list.html
    │   ├── detail.html
    │   └── form.html
    ├── events/
    │   ├── list.html
    │   └── form.html
    ├── tasks/
    │   ├── list.html
    │   └── form.html
    ├── announcements/
    │   ├── list.html
    │   └── form.html
    └── admin/
        ├── users.html
        └── clubs.html
```

## Grading Tips (20/20)

1. **Demonstrate all 3 roles** during your presentation
2. **Show the membership approval flow**: Member requests → Leader approves
3. **Show task tracking**: Assign task → Member marks complete
4. **Highlight responsive design**: Resize browser to show mobile view
5. **Show database via H2 Console**: Prove data persistence
6. **Code quality**: Clean package structure, proper MVC separation
7. **Security**: Show that unauthorized users cannot access admin pages

## Troubleshooting

**Port already in use:**
Add to `application.properties`: `server.port=8081`

**Database not persisting:**
H2 is in-memory. Data is re-initialized on every restart via `DataInitializer`.

**Login not working:**
Make sure you use the demo accounts with password `password`, or register a new account.
